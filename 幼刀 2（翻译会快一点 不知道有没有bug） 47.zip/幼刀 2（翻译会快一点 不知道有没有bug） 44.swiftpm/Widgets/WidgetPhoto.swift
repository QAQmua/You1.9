// MARK: - 6. WidgetPhoto (4×2 照片组件：自适应高度严丝合缝版)
import SwiftUI

class PhotoWidgetManager: ObservableObject {
    static let shared = PhotoWidgetManager()
    
    private let photoIdKey = "App_Widget_4x2_ImageID"
    private let addedKey = "App_Widget_4x2_IsAdded"
    private let pageKey = "App_Widget_4x2_PagePosition"
    private let rowKey = "App_Widget_4x2_RowPosition"
    
    @Published var widgetImageData: Data? {
        didSet {
            let oldId = UserDefaults.standard.string(forKey: photoIdKey)
            LocalImageStore.shared.replace(oldId: oldId, with: widgetImageData) { newId in
                UserDefaults.standard.set(newId, forKey: self.photoIdKey)
            }
        }
    }
    @Published var isAddedToDesktop: Bool { didSet { UserDefaults.standard.set(isAddedToDesktop, forKey: addedKey) } }
    @Published var widgetPage: Int { didSet { UserDefaults.standard.set(widgetPage, forKey: pageKey) } }
    @Published var widgetRow: Int { didSet { UserDefaults.standard.set(widgetRow, forKey: rowKey) } }
    
    init() {
        if let savedId = UserDefaults.standard.string(forKey: photoIdKey) {
            self.widgetImageData = LocalImageStore.shared.load(id: savedId)
        }
        self.isAddedToDesktop = UserDefaults.standard.bool(forKey: addedKey)
        self.widgetPage = UserDefaults.standard.integer(forKey: pageKey)
        let rawRow = UserDefaults.standard.integer(forKey: rowKey)
        self.widgetRow = min(max(0, rawRow), 4)
    }
}

struct PhotoWidget4x2View: View {
    var imageData: Data?
    var isEditing: Bool = false
    var onDelete: (() -> Void)? = nil
    
    @ObservedObject var appearance = SystemAppearance.shared
    @ObservedObject var translator = AutoTranslationManager.shared
    
    var body: some View {
        ZStack(alignment: .topLeading) {
            Group {
                // 💡 换用全局高性能缓存，绝不在拖拽时重复解压大图
                if let data = imageData, let uiImage = ImageBitmapCache.shared.image(from: data) {
                    Image(uiImage: uiImage).resizable().scaledToFill()
                } else {
                    ZStack {
                        LinearGradient(
                            colors: [Color.purple.opacity(0.35), Color.blue.opacity(0.25)],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                        VStack(spacing: 8) {
                            Image(systemName: "photo.on.rectangle.angled")
                                .font(.system(size: 32))
                                .foregroundColor(.white.opacity(0.9))
                            Text(translator.translate("卡片"))
                                .font(.subheadline)
                                .fontWeight(appearance.systemFontWeight)
                                .foregroundColor(.white)
                            Text(translator.translate("点击选取相册照片"))
                                .font(.caption2)
                                .fontWeight(appearance.systemFontWeight)
                                .foregroundColor(.white.opacity(0.8))
                        }
                    }
                }
            }
            // 🌟 彻底干掉内部写死的 160，让卡片撑满父容器 frame
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 22, style: .continuous)
                    .stroke(Color.white.opacity(0.18), lineWidth: 1)
            )
            .contentShape(Rectangle())
            
            if isEditing, let onDelete = onDelete {
                Button(action: onDelete) { WidgetDeleteBadge() }
                    .padding(8)
                    .transition(.scale.combined(with: .opacity))
            }
        }
        // 🌟 最外层同样删掉写死的 frame(height: 160)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

extension WidgetRegistry {
    func registerPhotoWidget() {
        registerWidget(
            id: "photo",
            title: "widget_photo_title",
            subtitle: "sub_photo",
            badge: "4×2",
            manager: PhotoWidgetManager.shared,
            desktopView: {
                PhotoWidget4x2View(imageData: PhotoWidgetManager.shared.widgetImageData, isEditing: false)
            },
            previewView: {
                PhotoWidget4x2View(imageData: PhotoWidgetManager.shared.widgetImageData, isEditing: false)
                    .frame(height: 160)
                    .padding(.horizontal, 16)
            },
            editSheetView: { _ in EmptyView() }
        )
    }
}
