// 📄 文件：IScreenView.swift (主容器)
import SwiftUI

struct IScreenView: View {
    @Binding var show: Bool
    
    // 实例化 ViewModel 中心
    @StateObject private var viewModel = IScreenViewModel()
    
    // 全局环境
    @ObservedObject var appearance = SystemAppearance.shared
    @ObservedObject var registry = WidgetRegistry.shared
    
    // 编辑弹窗绑定计算属性
    var activeEditWidgetBinding: Binding<Bool> {
        Binding(
            get: { viewModel.activeEditWidgetID != nil },
            set: { if !$0 { viewModel.activeEditWidgetID = nil } }
        )
    }
    
    private var activeEditingItemBinding: Binding<WidgetDefinition?> {
        Binding(
            get: {
                guard let id = viewModel.activeEditWidgetID else { return nil }
                return registry.registeredWidgets.first(where: { $0.id == id })
            },
            set: { viewModel.activeEditWidgetID = $0?.id }
        )
    }
    
    var body: some View {
        NavigationStack {
            TabView(selection: $viewModel.currentTab) {
                // 1. 首页模块
                IScreenHomeView(viewModel: viewModel)
                    .tabItem {
                        Image(systemName: "sparkles.rectangle.stack.fill")
                        Text("首页".tr)
                    }
                    .tag(0)
                
                // 2. 图标模块
                IScreenIconStudioView()
                    .tabItem {
                        Image(systemName: "photo.stack.fill")
                        Text("图标".tr)
                    }
                    .tag(1)
                
                // 3. 工坊模块
                IScreenWorkshopView()
                    .tabItem {
                        Image(systemName: "hammer.fill")
                        Text("工坊".tr)
                    }
                    .tag(2)
                
                // 4. 我的模块
                IScreenProfileView(viewModel: viewModel)
                    .tabItem {
                        Image(systemName: "person.crop.circle.fill")
                        Text("更多".tr)
                    }
                    .tag(3)
            }
            .navigationTitle(navigationTitle(for: viewModel.currentTab))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    // 全局返回按钮
                    Button(action: {
                        withAnimation(.spring(response: 0.32, dampingFraction: 0.86)) { show = false }
                    }) {
                        Image(systemName: "chevron.left")
                            .font(.system(size: 16, weight: appearance.systemFontWeight))
                            .foregroundColor(.primary)
                    }
                }
            }
            .background(Color(UIColor.systemBackground))
        }
        .preferredColorScheme(appearance.colorScheme)
        // 桌面系统的全局右滑退出手势
        .simultaneousGesture(
            DragGesture(minimumDistance: 15).onEnded { value in
                if value.translation.width > 50 && abs(value.translation.width) > abs(value.translation.height) {
                    UIImpactFeedbackGenerator(style: .light).impactOccurred()
                    withAnimation(.spring(response: 0.32, dampingFraction: 0.86)) { show = false }
                }
            }
        )
        // 统一小组件定制弹窗
        .sheet(item: activeEditingItemBinding) { widgetDef in
            widgetDef.editSheetView(activeEditWidgetBinding)
        }
    }
    
    // 动态导航栏标题
    private func navigationTitle(for tab: Int) -> String {
        switch tab {
        case 0: return "热门小组件".tr
        case 1: return "图标灵动工坊".tr
        case 2: return "我的自制库".tr
        case 3: return "个人中心".tr
        default: return "iScreen"
        }
    }
}
