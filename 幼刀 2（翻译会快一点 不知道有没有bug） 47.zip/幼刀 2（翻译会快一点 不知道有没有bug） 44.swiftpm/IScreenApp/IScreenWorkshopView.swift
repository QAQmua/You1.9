// 📄 新文件：IScreenWorkshopView.swift
import SwiftUI

struct IScreenWorkshopView: View {
    @ObservedObject var appearance = SystemAppearance.shared
    @ObservedObject var registry = WidgetRegistry.shared
    @ObservedObject var lang = LanguageManager.shared
    
    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 20) {
                HStack(spacing: 14) {
                    Button(action: {}) {
                        VStack(alignment: .leading, spacing: 12) {
                            Image(systemName: "plus.square.dashed").font(.system(size: 28)).foregroundColor(.blue)
                            VStack(alignment: .leading, spacing: 4) { Text("自制小组件".tr).font(.system(size: 17, weight: appearance.systemFontWeight)).foregroundColor(.primary); Text("画布自由排版".tr).font(.caption2).foregroundColor(.secondary) }
                        }.frame(maxWidth: .infinity, alignment: .leading).padding(16).background(Color(UIColor.secondarySystemGroupedBackground)).cornerRadius(18)
                    }
                    Button(action: {}) {
                        VStack(alignment: .leading, spacing: 12) {
                            Image(systemName: "square.and.arrow.down.fill").font(.system(size: 28)).foregroundColor(.blue)
                            VStack(alignment: .leading, spacing: 4) { Text("导入组件".tr).font(.system(size: 17, weight: appearance.systemFontWeight)).foregroundColor(.primary); Text("支持口令与代码".tr).font(.caption2).foregroundColor(.secondary) }
                        }.frame(maxWidth: .infinity, alignment: .leading).padding(16).background(Color(UIColor.secondarySystemGroupedBackground)).cornerRadius(18)
                    }
                }.padding(.horizontal, 16).padding(.top, 14)
                
                VStack(alignment: .leading, spacing: 14) {
                    Text("\("我的自制库".tr) (\(registry.registeredWidgets.count))").font(.system(size: 14, weight: appearance.systemFontWeight)).padding(.horizontal, 16)
                    
                    ForEach(registry.registeredWidgets) { widget in
                        VStack(alignment: .leading, spacing: 12) {
                            HStack {
                                VStack(alignment: .leading, spacing: 3) {
                                    Text(lang.tr(widget.titleKey)).font(.system(size: 17, weight: appearance.systemFontWeight))
                                    Text(lang.tr(widget.subtitleKey)).font(.caption2).foregroundColor(.secondary)
                                }
                                Spacer()
                                Text(widget.manager.isAddedToDesktop ? "已在桌面".tr : "未添加".tr).font(.caption2.weight(.medium)).padding(.horizontal, 8).padding(.vertical, 3).background(widget.manager.isAddedToDesktop ? Color.blue.opacity(0.1) : Color(UIColor.tertiarySystemFill)).foregroundColor(widget.manager.isAddedToDesktop ? .blue : .secondary).clipShape(Capsule())
                            }
                            
                            HStack {
                                if widget.sizeCols < 4 { Spacer() }
                                widget.previewView()
                                if widget.sizeCols < 4 { Spacer() }
                            }
                        }
                        .padding(16).background(Color(UIColor.secondarySystemGroupedBackground)).cornerRadius(20).padding(.horizontal, 16)
                    }
                }
            }.padding(.bottom, 20)
        }
    }
}
