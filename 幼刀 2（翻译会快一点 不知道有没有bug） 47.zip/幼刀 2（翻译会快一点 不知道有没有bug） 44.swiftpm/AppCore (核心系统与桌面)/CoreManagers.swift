// 📄 替换文件：AppCore (核心系统与桌面)/CoreManagers.swift
// MARK: - 2. CoreManagers (数据模型与全局系统管理器 · 极速预解码缓存版)
import SwiftUI
import UIKit
import Combine

// MARK: - App 实体模型
struct AppItem: Identifiable, Codable, Equatable {
    let id: String
    var title: String
    var icon: String
    var colorName: String
    
    var color: Color {
        switch colorName {
        case "gray": return .gray
        case "green": return .green
        case "blue": return .blue
        case "orange": return .orange
        case "red": return .red
        case "purple": return .purple
        default: return .gray
        }
    }
    
    func localizedTitle(customManager: CustomIconManager, lang: LanguageManager) -> String {
        if let custom = customManager.getTitle(for: self.id), !custom.isEmpty {
            return AutoTranslationManager.shared.translate(custom, to: lang.currentLanguage)
        }
        if self.id == "settings" { return lang.tr("app_settings") }
        if self.id == "wechat" { return lang.tr("app_wechat") }
        if self.id == "iscreen" { return lang.tr("app_iscreen") }
        if self.id == "phone" { return lang.tr("app_phone") }
        if self.id == "messages" { return lang.tr("app_messages") }
        if self.id == "weather" { return lang.tr("app_weather") }
        if self.id == "anonymous" { return lang.tr("app_anonymous") }
        if self.id == "qimao" { return lang.tr("app_qimao") }
        if self.id == "icity" { return lang.tr("app_icity") }
        if self.id == "notes" { return lang.tr("app_notes") }
        return AutoTranslationManager.shared.translate(self.title, to: lang.currentLanguage)
    }
}

// MARK: - 拖拽换位坐标定位枚举
enum AppLocation: Equatable {
    case grid(Int)
    case dock(Int)
    
    var isDock: Bool {
        if case .dock = self { return true }
        return false
    }
}

// MARK: - 设置应用全局路由枚举
enum SettingsRoute: Hashable {
    case language
    case appearance
    case wallpaper
    case apiConfig
}

class SettingsNavManager: ObservableObject {
    static let shared = SettingsNavManager()
    @Published var path: [SettingsRoute] = []
    /// 💡 滑块交互锁：当用户滑动滑块时锁定，禁止返回手势触发
    @Published var isInteractingWithSlider: Bool = false
}

// MARK: - 自定义 App 图标与名称管理器
class CustomIconManager: ObservableObject {
    static let shared = CustomIconManager()
    
    private let titleStorageKey = "App_Custom_App_Titles_Map"
    private let iconIdStorageKey = "App_Custom_App_IconIDs_Map"
    
    @Published var customIcons: [String: Data] = [:]
    
    @Published var customIconIDs: [String: String] = [:] {
        didSet {
            Task.detached(priority: .utility) {
                if let data = try? JSONEncoder().encode(self.customIconIDs) {
                    UserDefaults.standard.set(data, forKey: self.iconIdStorageKey)
                }
            }
        }
    }
    
    @Published var customTitles: [String: String] = [:] {
        didSet {
            Task.detached(priority: .utility) {
                if let data = try? JSONEncoder().encode(self.customTitles) {
                    UserDefaults.standard.set(data, forKey: self.titleStorageKey)
                }
            }
        }
    }
    
    init() {
        if let data = UserDefaults.standard.data(forKey: titleStorageKey),
           let decoded = try? JSONDecoder().decode([String: String].self, from: data) {
            self.customTitles = decoded
            for title in self.customTitles.values {
                AutoTranslationManager.shared.prewarm(text: title)
            }
        }
        
        if let data = UserDefaults.standard.data(forKey: iconIdStorageKey),
           let decoded = try? JSONDecoder().decode([String: String].self, from: data) {
            self.customIconIDs = decoded
            for (appId, imageId) in decoded {
                if let imageData = LocalImageStore.shared.load(id: imageId) {
                    self.customIcons[appId] = imageData
                    _ = ImageBitmapCache.shared.image(from: imageData)
                }
            }
        }
    }
    
    func setIcon(for appId: String, imageData: Data) {
        customIcons[appId] = imageData
        _ = ImageBitmapCache.shared.image(from: imageData)
        
        let oldId = customIconIDs[appId]
        LocalImageStore.shared.replace(oldId: oldId, with: imageData) { newId in
            if let newId = newId {
                self.customIconIDs[appId] = newId
            }
        }
    }
    
    func removeIcon(for appId: String) {
        if let oldData = customIcons[appId] {
            ImageBitmapCache.shared.remove(for: oldData)
        }
        customIcons.removeValue(forKey: appId)
        if let oldId = customIconIDs[appId] {
            LocalImageStore.shared.delete(id: oldId)
            customIconIDs.removeValue(forKey: appId)
        }
    }
    
    func getIcon(for appId: String) -> Data? {
        return customIcons[appId]
    }
    
    func setTitle(for appId: String, title: String) {
        let trimmed = title.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed.isEmpty {
            customTitles.removeValue(forKey: appId)
        } else {
            customTitles[appId] = trimmed
            Task {
                for lang in AppLanguage.allCases where lang != .simplifiedChinese {
                    _ = await AutoTranslationManager.shared.translateAsync(trimmed, to: lang)
                }
            }
        }
    }
    
    func removeTitle(for appId: String) {
        customTitles.removeValue(forKey: appId)
    }
    
    func getTitle(for appId: String) -> String? {
        return customTitles[appId]
    }
}

// MARK: - 外观与系统设置管理
class SystemAppearance: ObservableObject {
    static let shared = SystemAppearance()
    
    @Published var isAuto: Bool = true { didSet { UserDefaults.standard.set(isAuto, forKey: "App_isAutoTheme") } }
    @Published var isDark: Bool = true { didSet { UserDefaults.standard.set(isDark, forKey: "App_isDarkTheme") } }
    @Published var hideHomeIndicator: Bool = false { didSet { UserDefaults.standard.set(hideHomeIndicator, forKey: "App_hideHomeIndicator") } }
    @Published var hideStatusBar: Bool = false { didSet { UserDefaults.standard.set(hideStatusBar, forKey: "App_hideStatusBar") } }
    @Published var systemFontWeightName: String = "regular" { didSet { UserDefaults.standard.set(systemFontWeightName, forKey: "App_systemFontWeightName") } }
    @Published var preferWidgetFontPriority: Bool = true { didSet { UserDefaults.standard.set(preferWidgetFontPriority, forKey: "App_preferWidgetFontPriority") } }
    
    var systemFontWeight: Font.Weight { Font.Weight.from(name: systemFontWeightName) }
    
    init() {
        if let autoVal = UserDefaults.standard.object(forKey: "App_isAutoTheme") as? Bool { self.isAuto = autoVal }
        if let darkVal = UserDefaults.standard.object(forKey: "App_isDarkTheme") as? Bool { self.isDark = darkVal }
        if let indicatorVal = UserDefaults.standard.object(forKey: "App_hideHomeIndicator") as? Bool { self.hideHomeIndicator = indicatorVal }
        if let statusVal = UserDefaults.standard.object(forKey: "App_hideStatusBar") as? Bool { self.hideStatusBar = statusVal }
        if let fontVal = UserDefaults.standard.string(forKey: "App_systemFontWeightName") { self.systemFontWeightName = fontVal }
        if let widgetPriorityVal = UserDefaults.standard.object(forKey: "App_preferWidgetFontPriority") as? Bool { self.preferWidgetFontPriority = widgetPriorityVal }
    }
    
    var colorScheme: ColorScheme? {
        if isAuto { return nil }
        return isDark ? .dark : .light
    }
}

extension View {
    @ViewBuilder
    func applyCustomAppearance(_ appearance: SystemAppearance) -> some View {
        if !appearance.isAuto {
            self.environment(\.colorScheme, appearance.isDark ? .dark : .light)
        } else {
            self
        }
    }
}

// MARK: - 壁纸管理 (预解码 UIImage，滑动时绝不解压)
@MainActor
class WallpaperManager: ObservableObject {
    static let shared = WallpaperManager()
    
    private let lockImageIdKey = "App_LockWallpaper_ImageID"
    private let homeImageIdKey = "App_HomeWallpaper_ImageID"
    
    @Published var homeScreenImage: UIImage?
    @Published var lockScreenImage: UIImage?
    
    @Published var lockScreenData: Data? {
        didSet {
            self.lockScreenImage = ImageBitmapCache.shared.image(from: lockScreenData)
            updateTones()
            let oldId = UserDefaults.standard.string(forKey: lockImageIdKey)
            LocalImageStore.shared.replace(oldId: oldId, with: lockScreenData) { newId in
                UserDefaults.standard.set(newId, forKey: self.lockImageIdKey)
            }
        }
    }
    
    @Published var homeScreenData: Data? {
        didSet {
            self.homeScreenImage = ImageBitmapCache.shared.image(from: homeScreenData)
            updateTones()
            let oldId = UserDefaults.standard.string(forKey: homeImageIdKey)
            LocalImageStore.shared.replace(oldId: oldId, with: homeScreenData) { newId in
                UserDefaults.standard.set(newId, forKey: self.homeImageIdKey)
            }
        }
    }
    
    // 🌟 核心修改点：未自定义图片时的默认壁纸状态被设为亮色系白色背景，自动匹配反差色文本 (黑色)
    @Published var isLockLight: Bool = true
    @Published var isHomeLight: Bool = true
    @Published var homeTextColor: Color = Color(hex: "#1A1A1A")
    @Published var lockTextColor: Color = Color(hex: "#1A1A1A")
    
    init() {
        if let lockId = UserDefaults.standard.string(forKey: lockImageIdKey) {
            let data = LocalImageStore.shared.load(id: lockId)
            self.lockScreenData = data
            self.lockScreenImage = ImageBitmapCache.shared.image(from: data)
        }
        if let homeId = UserDefaults.standard.string(forKey: homeImageIdKey) {
            let data = LocalImageStore.shared.load(id: homeId)
            self.homeScreenData = data
            self.homeScreenImage = ImageBitmapCache.shared.image(from: data)
        }
        updateTones()
    }
    
    func updateTones() {
        if let img = lockScreenImage ?? (lockScreenData != nil ? UIImage(data: lockScreenData!) : nil) {
            let analysis = img.analyzeWallpaperTone()
            self.isLockLight = analysis.isLight
            self.lockTextColor = analysis.textColor
        } else {
            // 没有自定义壁纸的默认处理
            self.isLockLight = true
            self.lockTextColor = Color(hex: "#1A1A1A")
        }
        if let img = homeScreenImage ?? (homeScreenData != nil ? UIImage(data: homeScreenData!) : nil) {
            let analysis = img.analyzeWallpaperTone()
            self.isHomeLight = analysis.isLight
            self.homeTextColor = analysis.textColor
        } else {
            // 没有自定义壁纸的默认处理
            self.isHomeLight = true
            self.homeTextColor = Color(hex: "#1A1A1A")
        }
    }
}
