// MARK: - 10. SettingsView (设置应用中心)
import SwiftUI
import PhotosUI
import UIKit

struct SettingsView: View {
    @Binding var show: Bool
    @ObservedObject var appearance = SystemAppearance.shared 
    @ObservedObject var lang = LanguageManager.shared
    @ObservedObject var navManager = SettingsNavManager.shared
    
    var body: some View {
        NavigationStack(path: $navManager.path) {
            List {
                Section {
                    HStack(spacing: 15) {
                        Image(systemName: "person.crop.circle.fill")
                            .font(.system(size: 45))
                            .foregroundColor(.gray)
                        VStack(alignment: .leading, spacing: 4) {
                            Text(lang.tr("device_name"))
                                .font(.system(size: 19, weight: appearance.systemFontWeight))
                            Text(lang.tr("apple_id_sub"))
                                .font(.system(size: 12, weight: appearance.systemFontWeight))
                                .foregroundColor(.gray)
                        }
                    }
                    .padding(.vertical, 4)
                }
                
                Section {
                    NavigationLink(value: SettingsRoute.language) {
                        HStack {
                            Image(systemName: "globe")
                                .font(.system(size: 14))
                                .foregroundColor(.white)
                                .frame(width: 28, height: 28)
                                .background(Color.blue)
                                .cornerRadius(6)
                            Text(lang.tr("language_title"))
                                .font(.system(size: 16, weight: appearance.systemFontWeight))
                            Spacer()
                            Text(lang.currentLanguage.displayName)
                                .font(.system(size: 14, weight: appearance.systemFontWeight))
                                .foregroundColor(.secondary)
                        }
                    }
                    
                    NavigationLink(value: SettingsRoute.appearance) {
                        HStack {
                            Image(systemName: "textformat.size")
                                .font(.system(size: 14))
                                .foregroundColor(.white)
                                .frame(width: 28, height: 28)
                                .background(Color.blue)
                                .cornerRadius(6)
                            Text(lang.tr("display_and_brightness"))
                                .font(.system(size: 16, weight: appearance.systemFontWeight))
                        }
                    }
                    
                    NavigationLink(value: SettingsRoute.wallpaper) {
                        HStack {
                            Image(systemName: "photo.on.rectangle")
                                .font(.system(size: 14))
                                .foregroundColor(.white)
                                .frame(width: 28, height: 28)
                                .background(Color.cyan)
                                .cornerRadius(6)
                            Text(lang.tr("wallpaper"))
                                .font(.system(size: 16, weight: appearance.systemFontWeight))
                        }
                    }
                }
                
                Section {
                    NavigationLink(value: SettingsRoute.apiConfig) {
                        HStack {
                            Image(systemName: "network")
                                .font(.system(size: 14))
                                .foregroundColor(.white)
                                .frame(width: 28, height: 28)
                                .background(Color.blue)
                                .cornerRadius(6)
                            Text(lang.tr("api_config"))
                                .font(.system(size: 16, weight: appearance.systemFontWeight))
                        }
                    }
                }
            }
            .navigationDestination(for: SettingsRoute.self) { route in
                switch route {
                case .language:
                    LanguageSettingsView()
                case .appearance:
                    AppearanceSettingsView()
                case .wallpaper:
                    WallpaperSettingsView()
                case .apiConfig:
                    APIConfigSettingsView()
                }
            }
            .navigationTitle(lang.tr("settings_title"))
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(lang.tr("done")) {
                        withAnimation(.spring(response: 0.32, dampingFraction: 0.86)) {
                            show = false
                            navManager.path = []
                        }
                    }
                    .font(.system(size: 16, weight: appearance.systemFontWeight))
                }
            }
            .background(Color(UIColor.systemBackground))
        }
        .preferredColorScheme(appearance.colorScheme)
        .simultaneousGesture(
            DragGesture(minimumDistance: 15)
                .onEnded { value in
                    // 💡 关键：若正在调整滑条，彻底拦截返回动作
                    guard !navManager.isInteractingWithSlider else { return }
                    
                    if value.translation.width > 50 && abs(value.translation.width) > abs(value.translation.height) {
                        let generator = UIImpactFeedbackGenerator(style: .light)
                        generator.impactOccurred()
                        
                        if !navManager.path.isEmpty {
                            withAnimation(.easeInOut(duration: 0.22)) {
                                _ = navManager.path.popLast()
                            }
                        } else {
                            withAnimation(.spring(response: 0.32, dampingFraction: 0.86)) {
                                show = false
                            }
                        }
                    }
                }
        )
    }
}

// MARK: - 语言设置子页面
struct LanguageSettingsView: View {
    @ObservedObject var lang = LanguageManager.shared
    @ObservedObject var appearance = SystemAppearance.shared
    
    var body: some View {
        List {
            Section {
                ForEach(AppLanguage.allCases) { item in
                    HStack {
                        Text(item.displayName)
                            .font(.system(size: 16, weight: appearance.systemFontWeight))
                            .foregroundColor(.primary)
                        Spacer()
                        Image(systemName: "checkmark")
                            .foregroundColor(.blue)
                            .font(.system(size: 14, weight: .bold))
                            .opacity(lang.currentLanguage == item ? 1.0 : 0.0)
                    }
                    .contentShape(Rectangle())
                    .onTapGesture {
                        let generator = UIImpactFeedbackGenerator(style: .light)
                        generator.impactOccurred()
                        lang.currentLanguage = item
                    }
                }
            }
        }
        .navigationTitle(lang.tr("language_title"))
        .navigationBarTitleDisplayMode(.inline)
    }
}

// MARK: - 外观与亮度设置
struct AppearanceSettingsView: View {
    @ObservedObject var appearance = SystemAppearance.shared
    @ObservedObject var lang = LanguageManager.shared
    
    private let fontWeights: [(key: String, title: String)] = [
        ("light", "细体"),
        ("regular", "标准"),
        ("medium", "中等"),
        ("semibold", "半粗"),
        ("bold", "粗体")
    ]
    
    var body: some View {
        Form {
            Section(
                header: Text(lang.tr("appearance")).font(.system(size: 13, weight: appearance.systemFontWeight)),
                footer: Text(lang.tr("appearance_auto_footer")).font(.system(size: 12, weight: appearance.systemFontWeight))
            ) {
                Toggle(lang.tr("auto"), isOn: $appearance.isAuto)
                    .font(.system(size: 16, weight: appearance.systemFontWeight))
                
                if !appearance.isAuto {
                    Picker(lang.tr("appearance_selection"), selection: $appearance.isDark) {
                        Text(lang.tr("light")).tag(false)
                        Text(lang.tr("dark")).tag(true)
                    }
                    .pickerStyle(.segmented)
                    .padding(.vertical, 4)
                }
            }
            
            Section(
                header: Text(lang.tr("font_weight_section")).font(.system(size: 13, weight: appearance.systemFontWeight)),
                footer: Text(lang.tr("widget_font_priority_footer")).font(.system(size: 12, weight: appearance.systemFontWeight))
            ) {
                Picker(lang.tr("font_weight_section"), selection: $appearance.systemFontWeightName) {
                    ForEach(fontWeights, id: \.key) { fw in
                        Text(fw.title.tr).tag(fw.key)
                    }
                }
                .pickerStyle(.segmented)
                .padding(.vertical, 4)
                
                Toggle(lang.tr("widget_font_priority"), isOn: $appearance.preferWidgetFontPriority)
                    .font(.system(size: 16, weight: appearance.systemFontWeight))
            }
            
            Section(header: Text(lang.tr("desktop_and_indicators")).font(.system(size: 13, weight: appearance.systemFontWeight))) {
                Toggle(lang.tr("hide_home_indicator"), isOn: $appearance.hideHomeIndicator)
                    .font(.system(size: 16, weight: appearance.systemFontWeight))
                Toggle(lang.tr("hide_status_bar"), isOn: $appearance.hideStatusBar)
                    .font(.system(size: 16, weight: appearance.systemFontWeight))
            }
        }
        .navigationTitle(lang.tr("display_and_brightness"))
        .navigationBarTitleDisplayMode(.inline)
    }
}

// MARK: - 壁纸设置子页面
struct WallpaperSettingsView: View {
    @ObservedObject var wallpaperManager = WallpaperManager.shared
    @ObservedObject var lang = LanguageManager.shared
    @ObservedObject var appearance = SystemAppearance.shared
    
    @State private var lockScreenItem: PhotosPickerItem? = nil
    @State private var homeScreenItem: PhotosPickerItem? = nil
    
    var body: some View {
        ScrollView {
            VStack(spacing: 35) {
                HStack(spacing: 25) {
                    VStack(spacing: 16) {
                        WallpaperPreviewBox(isLockScreen: true, wallpaperData: wallpaperManager.lockScreenData)
                        Text(lang.tr("lock_screen"))
                            .font(.system(size: 15, weight: appearance.systemFontWeight))
                        
                        PhotosPicker(selection: $lockScreenItem, matching: .images, photoLibrary: .shared()) {
                            Text(lang.tr("customize"))
                                .font(.system(size: 14, weight: appearance.systemFontWeight))
                                .foregroundColor(.primary) 
                                .padding(.horizontal, 16)
                                .padding(.vertical, 6)
                                .background(Color.primary.opacity(0.1)) 
                                .clipShape(Capsule())
                        }
                    }
                    
                    VStack(spacing: 16) {
                        WallpaperPreviewBox(isLockScreen: false, wallpaperData: wallpaperManager.homeScreenData)
                        Text(lang.tr("home_screen"))
                            .font(.system(size: 15, weight: appearance.systemFontWeight))
                        
                        PhotosPicker(selection: $homeScreenItem, matching: .images, photoLibrary: .shared()) {
                            Text(lang.tr("customize"))
                                .font(.system(size: 14, weight: appearance.systemFontWeight))
                                .foregroundColor(.primary) 
                                .padding(.horizontal, 16)
                                .padding(.vertical, 6)
                                .background(Color.primary.opacity(0.1)) 
                                .clipShape(Capsule())
                        }
                    }
                }
                .padding(.top, 40)
            }
        }
        .navigationTitle(lang.tr("wallpaper"))
        .navigationBarTitleDisplayMode(.inline)
        .task(id: lockScreenItem) {
            if let data = try? await lockScreenItem?.loadTransferable(type: Data.self) {
                withAnimation(.easeInOut(duration: 0.5)) {
                    wallpaperManager.lockScreenData = data
                }
            }
        }
        .task(id: homeScreenItem) {
            if let data = try? await homeScreenItem?.loadTransferable(type: Data.self) {
                withAnimation(.easeInOut(duration: 0.5)) {
                    wallpaperManager.homeScreenData = data
                }
            }
        }
    }
}

// MARK: - 壁纸预览容器
struct WallpaperPreviewBox: View {
    var isLockScreen: Bool
    var wallpaperData: Data?
    
    var body: some View {
        ZStack(alignment: isLockScreen ? .top : .bottom) {
            NativeImage(data: wallpaperData)
                .frame(width: 140, height: 300)
                .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 22, style: .continuous)
                        .stroke(Color.gray.opacity(0.3), lineWidth: 3)
                )
            
            if isLockScreen {
                Text("09:41").font(.system(size: 26, weight: .thin)).padding(.top, 30).foregroundColor(.white)
            } else {
                RoundedRectangle(cornerRadius: 10, style: .continuous)
                    .fill(Color.gray.opacity(0.3))
                    .frame(width: 100, height: 24)
                    .padding(.bottom, 20)
            }
        }
    }
}
