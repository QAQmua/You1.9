import SwiftUI

// MARK: - 全局 AI API 配置与请求管理中心
@MainActor
final class AIApiManager: ObservableObject {
    static let shared = AIApiManager()
    
    private let kBaseURL = "App_AI_BaseURL_Key"
    private let kApiKey = "App_AI_ApiKey_Key"
    private let kSelectedModel = "App_AI_SelectedModel_Key"
    private let kCachedModels = "App_AI_CachedModels_Key"
    private let kTemperature = "App_AI_Temperature_Key"
    
    @Published var baseURL: String {
        didSet { UserDefaults.standard.set(baseURL, forKey: kBaseURL) }
    }
    @Published var apiKey: String {
        didSet { UserDefaults.standard.set(apiKey, forKey: kApiKey) }
    }
    @Published var selectedModel: String {
        didSet { UserDefaults.standard.set(selectedModel, forKey: kSelectedModel) }
    }
    @Published var availableModels: [String] {
        didSet { UserDefaults.standard.set(availableModels, forKey: kCachedModels) }
    }
    @Published var temperature: Double {
        didSet { UserDefaults.standard.set(temperature, forKey: kTemperature) }
    }
    
    @Published var isFetching: Bool = false
    @Published var statusMessage: String? = nil
    @Published var isSuccess: Bool = false
    
    init() {
        self.baseURL = UserDefaults.standard.string(forKey: kBaseURL) ?? "https://api.openai.com/v1"
        self.apiKey = UserDefaults.standard.string(forKey: kApiKey) ?? ""
        self.selectedModel = UserDefaults.standard.string(forKey: kSelectedModel) ?? "gpt-4o"
        self.availableModels = UserDefaults.standard.stringArray(forKey: kCachedModels) ?? [
            "gpt-4o", "gpt-4o-mini", "claude-3-5-sonnet", "deepseek-chat", "deepseek-reasoner"
        ]
        let savedTemp = UserDefaults.standard.object(forKey: kTemperature) as? Double
        self.temperature = savedTemp ?? 0.7
    }
    
    var cleanBaseURL: String {
        var url = baseURL.trimmingCharacters(in: .whitespacesAndNewlines)
        if url.hasSuffix("/") { url.removeLast() }
        return url
    }
    
    private var modelsURL: URL? {
        let base = cleanBaseURL
        if base.isEmpty { return nil }
        if base.hasSuffix("/v1") {
            return URL(string: "\(base)/models")
        } else {
            return URL(string: "\(base)/v1/models") ?? URL(string: "\(base)/models")
        }
    }
    
    func fetchModels() async {
        guard let url = modelsURL else {
            self.statusMessage = "接口地址格式不正确".tr
            self.isSuccess = false
            return
        }
        
        let token = apiKey.trimmingCharacters(in: .whitespacesAndNewlines)
        isFetching = true
        statusMessage = nil
        
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.timeoutInterval = 8
        if !token.isEmpty {
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        
        do {
            let (data, response) = try await URLSession.shared.data(for: request)
            guard let httpResponse = response as? HTTPURLResponse else {
                throw URLError(.badServerResponse)
            }
            
            if httpResponse.statusCode == 200 {
                if let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                   let dataList = json["data"] as? [[String: Any]] {
                    let parsedModels = dataList.compactMap { $0["id"] as? String }.sorted()
                    if !parsedModels.isEmpty {
                        self.availableModels = parsedModels
                        if !parsedModels.contains(self.selectedModel) {
                            self.selectedModel = parsedModels[0]
                        }
                        self.isSuccess = true
                        self.statusMessage = "已成功拉取 \(parsedModels.count) 个可用模型".tr
                        UINotificationFeedbackGenerator().notificationOccurred(.success)
                        self.isFetching = false
                        return
                    }
                }
                self.isSuccess = true
                self.statusMessage = "连接成功（未解析到有效模型数据）".tr
            } else if httpResponse.statusCode == 401 {
                self.isSuccess = false
                self.statusMessage = "认证失败 (401)：请检查 API Key 是否正确".tr
                UINotificationFeedbackGenerator().notificationOccurred(.error)
            } else {
                self.isSuccess = false
                self.statusMessage = "请求异常，HTTP 状态码: \(httpResponse.statusCode)"
                UINotificationFeedbackGenerator().notificationOccurred(.error)
            }
        } catch {
            self.isSuccess = false
            self.statusMessage = "连接超时，无法访问反代端点".tr
            UINotificationFeedbackGenerator().notificationOccurred(.error)
        }
        
        self.isFetching = false
    }
}

// MARK: - 极简原生风 API 反代配置界面
struct APIConfigSettingsView: View {
    @StateObject private var apiManager = AIApiManager.shared
    @ObservedObject var appearance = SystemAppearance.shared
    @ObservedObject var lang = LanguageManager.shared
    
    @State private var isSecuredKey: Bool = true
    @State private var showCustomModelAlert: Bool = false
    @State private var customModelText: String = ""
    
    private let presetProxies: [(name: String, url: String)] = [
        ("OpenAI", "https://api.openai.com/v1"),
        ("DeepSeek", "https://api.deepseek.com/v1"),
        ("Moonshot", "https://api.moonshot.cn/v1"),
        ("Localhost", "http://127.0.0.1:8000/v1")
    ]
    
    var body: some View {
        Form {
            // MARK: - 基础服务
            Section(header: Text("服务连接".tr)) {
                HStack {
                    Text("反代地址".tr)
                        .frame(width: 80, alignment: .leading)
                    TextField("https://api.openai.com/v1", text: $apiManager.baseURL)
                        .autocorrectionDisabled()
                        .textInputAutocapitalization(.never)
                        .font(.system(size: 15))
                    
                    Menu {
                        ForEach(presetProxies, id: \.url) { item in
                            Button(item.name) {
                                apiManager.baseURL = item.url
                            }
                        }
                    } label: {
                        Text("预设".tr)
                            .font(.system(size: 13, weight: .medium))
                            .foregroundColor(.blue)
                    }
                }
                
                HStack {
                    Text("API 密钥".tr)
                        .frame(width: 80, alignment: .leading)
                    
                    if isSecuredKey {
                        SecureField("sk-...", text: $apiManager.apiKey)
                            .font(.system(size: 15))
                    } else {
                        TextField("sk-...", text: $apiManager.apiKey)
                            .autocorrectionDisabled()
                            .textInputAutocapitalization(.never)
                            .font(.system(size: 15))
                    }
                    
                    Button(action: { isSecuredKey.toggle() }) {
                        Image(systemName: isSecuredKey ? "eye.slash" : "eye")
                            .font(.system(size: 14))
                            .foregroundColor(.secondary)
                    }
                    .buttonStyle(.plain)
                }
            }
            
            // MARK: - 模型与推理参数
            Section(
                header: Text("模型与生成参数".tr),
                footer: Text("较低温度输出更严谨确定，较高温度输出更发散创造。".tr)
            ) {
                // 模型选择
                HStack {
                    Text("模型".tr)
                        .frame(width: 80, alignment: .leading)
                    
                    Picker("", selection: $apiManager.selectedModel) {
                        ForEach(apiManager.availableModels, id: \.self) { model in
                            Text(model).tag(model)
                        }
                    }
                    .labelsHidden()
                    
                    Spacer()
                    
                    Button(action: {
                        customModelText = apiManager.selectedModel
                        showCustomModelAlert = true
                    }) {
                        Text("自定义".tr)
                            .font(.system(size: 13))
                            .foregroundColor(.blue)
                    }
                    .buttonStyle(.plain)
                }
                
                // 拉取模型
                Button(action: {
                    Task { await apiManager.fetchModels() }
                }) {
                    HStack {
                        Text(apiManager.isFetching ? "正在拉取模型列表...".tr : "从反代服务器拉取模型".tr)
                            .foregroundColor(apiManager.isFetching ? .secondary : .blue)
                        Spacer()
                        if apiManager.isFetching {
                            ProgressView()
                                .scaleEffect(0.85)
                        }
                    }
                }
                .disabled(apiManager.isFetching)
                
                // 💡 温度调节（带有互斥锁 + 细粒度加减微调按钮）
                VStack(spacing: 8) {
                    HStack {
                        Text("温度 (Temperature)".tr)
                        Spacer()
                        Text(String(format: "%.2f", apiManager.temperature))
                            .font(.system(size: 15, weight: .medium, design: .monospaced))
                            .foregroundColor(.secondary)
                    }
                    
                    HStack(spacing: 12) {
                        Button(action: {
                            UIImpactFeedbackGenerator(style: .light).impactOccurred()
                            apiManager.temperature = max(0.0, ((apiManager.temperature - 0.05) * 100).rounded() / 100)
                        }) {
                            Image(systemName: "minus")
                                .font(.system(size: 11, weight: .bold))
                                .foregroundColor(.secondary)
                                .frame(width: 26, height: 26)
                                .background(Color(UIColor.tertiarySystemFill))
                                .clipShape(Circle())
                        }
                        .buttonStyle(.plain)
                        
                        Slider(
                            value: $apiManager.temperature,
                            in: 0.0...2.0,
                            step: 0.05,
                            onEditingChanged: { editing in
                                if editing {
                                    // 用户手势刚摸到滑条 -> 立刻锁定全局返回
                                    SettingsNavManager.shared.isInteractingWithSlider = true
                                } else {
                                    // 松手后缓冲 300 毫秒，保证滑动手势结束彻底消化后再解锁
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                                        SettingsNavManager.shared.isInteractingWithSlider = false
                                    }
                                }
                            }
                        )
                        
                        Button(action: {
                            UIImpactFeedbackGenerator(style: .light).impactOccurred()
                            apiManager.temperature = min(2.0, ((apiManager.temperature + 0.05) * 100).rounded() / 100)
                        }) {
                            Image(systemName: "plus")
                                .font(.system(size: 11, weight: .bold))
                                .foregroundColor(.secondary)
                                .frame(width: 26, height: 26)
                                .background(Color(UIColor.tertiarySystemFill))
                                .clipShape(Circle())
                        }
                        .buttonStyle(.plain)
                    }
                    
                    HStack {
                        Text("精确 0.0".tr)
                            .font(.system(size: 11))
                            .foregroundColor(.secondary)
                        Spacer()
                        Text("发散 2.0".tr)
                            .font(.system(size: 11))
                            .foregroundColor(.secondary)
                    }
                }
                .padding(.vertical, 4)
            }
            
            // MARK: - 诊断状态反馈
            if let msg = apiManager.statusMessage {
                Section {
                    HStack(spacing: 8) {
                        Circle()
                            .fill(apiManager.isSuccess ? Color.green : Color.red)
                            .frame(width: 7, height: 7)
                        Text(msg)
                            .font(.system(size: 13))
                            .foregroundColor(apiManager.isSuccess ? .secondary : .red)
                    }
                    .padding(.vertical, 2)
                }
            }
        }
        .navigationTitle(lang.tr("api_config"))
        .navigationBarTitleDisplayMode(.inline)
        .alert("输入自定义模型".tr, isPresented: $showCustomModelAlert) {
            TextField("如: claude-3-7-sonnet", text: $customModelText)
            Button("确定".tr) {
                let trimmed = customModelText.trimmingCharacters(in: .whitespacesAndNewlines)
                if !trimmed.isEmpty {
                    if !apiManager.availableModels.contains(trimmed) {
                        apiManager.availableModels.insert(trimmed, at: 0)
                    }
                    apiManager.selectedModel = trimmed
                }
            }
            Button("取消".tr, role: .cancel) {}
        }
    }
}
